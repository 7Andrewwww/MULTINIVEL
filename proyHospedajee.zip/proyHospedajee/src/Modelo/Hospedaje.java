/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public abstract class Hospedaje {
     
    protected int canDia;
    protected int numPer;
    protected double precio;
    
    // Constructor
    public Hospedaje(int canDia, int numPer, double precio) {
        this.canDia = canDia;
        this.numPer = numPer;
        this.precio = precio;
        
    }
    
     public Hospedaje() {
        this.canDia = 0;
        this.numPer = 0;
        this.precio = 0;
        
    }
    
    // Métodos abstractos
    public abstract double valorPagar();
    public abstract double descuento();
    
    // Métodos getters y setters
    public int getCanDia() {
        return canDia;
    }

    public void setCanDia(int canDia) {
        this.canDia = canDia;
    }

    public int getNumPer() {
        return numPer;
    }

    public void setNumPer(int numPer) {
        this.numPer = numPer;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Hospedaje{" + "canDia=" + canDia + ", numPer=" + numPer + ", precio=" + precio + '}';
    }
    
}

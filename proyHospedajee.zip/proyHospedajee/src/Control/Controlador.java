/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.*;
import Vista.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author A n d r e s
 */
public class Controlador implements ActionListener {

    private Factura objF;
    private Ventana frmV;

    public Controlador() {
        this.objF = new Factura();
        this.frmV = new Ventana();
        this.frmV.getButtonGroup2().add(frmV.getRbtnGlamping());
        this.frmV.getButtonGroup2().add(frmV.getRbtnHabitacion());
        this.frmV.getBtnRegistrar().addActionListener(this);
    }

    public void iniciar() {
        frmV.setTitle("...Hospedaje....");
        frmV.setLocationRelativeTo(null);
        frmV.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (frmV.getBtnRegistrar() == e.getSource() && frmV.getRbtnHabitacion().isSelected()) {
            Habitacion objH = new Habitacion();
            objH.setCanDia(Integer.parseInt(frmV.getTxtNoches().getText()));
            objH.setNumPer(Integer.parseInt(frmV.getTxtPersonas().getText()));
            objF.getCliente().setNombre(frmV.getTxtNombre().getText());
            objF.getCliente().setId(frmV.getTxtId().getText());
            objF.getCliente().setTel(frmV.getTxtTel().getText());
            frmV.getTxtaResp().append(objH.toString() + objF.valorTotal());

        }
        if (frmV.getBtnRegistrar() == e.getSource() && frmV.getRbtnGlamping().isSelected()) {
            Camping objC = new Camping();
            objC.setCanDia(Integer.parseInt(frmV.getTxtNoches().getText()));
            objC.setNumPer(Integer.parseInt(frmV.getTxtPersonas().getText()));
            objF.getCliente().setNombre(frmV.getTxtNombre().getText());
            objF.getCliente().setId(frmV.getTxtId().getText());
            objF.getCliente().setTel(frmV.getTxtTel().getText());
            frmV.getTxtaResp().append(objC.toString() + objF.valorTotal());

        }
    }

}

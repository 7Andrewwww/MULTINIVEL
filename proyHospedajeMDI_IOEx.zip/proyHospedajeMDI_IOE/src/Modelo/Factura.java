/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public class Factura {

    private double IVA;
    private Fecha fechi;
    private Hospedaje hospedaje;
    private Cliente cliente;

    public Factura(double IVA, Fecha fechi, Hospedaje hospedaje, Cliente cliente) {
        this.IVA = IVA;
        this.fechi = fechi;
        this.hospedaje = hospedaje;
        this.cliente = cliente;
    }

    public Factura() {
        this.IVA = 0;
        this.fechi = new Fecha();
        this.cliente = new Cliente();

    }

    public double getIVA() {
        return IVA;
    }

    public void setIVA(double IVA) {
        this.IVA = IVA;
    }

    public Fecha getFechi() {
        return fechi;
    }

    public void setFechi(Fecha fechi) {
        this.fechi = fechi;
    }

    public Hospedaje getHospedaje() {
        return hospedaje;
    }

    public void setHospedaje(Hospedaje hospedaje) {
        this.hospedaje = hospedaje;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double valorTotal() {
        return hospedaje.valorPagar() * IVA;
    }

    @Override
    public String toString() {
        return "Factura"
                + "Valor Total" + valorTotal()
                + "IVA=" + IVA
                + "Fecha=" + fechi.toString()
                + "Hospedaje=" + hospedaje.toString()
                + "Cliente" + cliente.toString();
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author A n d r e s
 */
public class ControladorMDI implements ActionListener {

    private Factura objF;
    private MDIHospedaje frmH;

    public ControladorMDI() {
        this.objF = new Factura();
        this.frmH = new MDIHospedaje();
        this.frmH.getMnuDatosHo().addActionListener(this);
        this.frmH.getMnuDatosUs().addActionListener(this);
        this.frmH.getMnuSalir().addActionListener(this);
        this.frmH.getBtnDatosHo().addActionListener(this);
        this.frmH.getBtnDatosUs().addActionListener(this);
        this.frmH.getBtnSalir().addActionListener(this);
    }

    public void iniciar() {
        frmH.setTitle("Registro Hospedaje");
        frmH.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmH.setLocationRelativeTo(null);
        frmH.setVisible(true);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmH.getMnuSalir()) || e.getSource().equals(frmH.getBtnSalir())) {
            int resp = JOptionPane.showConfirmDialog(frmH, "Desea terminar la ejecucion?");
            if (resp == JOptionPane.YES_NO_OPTION) {
                frmH.dispose();//cierra limpia
            }
        }

        if (e.getSource().equals(frmH.getMnuDatosHo()) || e.getSource().equals(frmH.getBtnDatosHo())) {
            JIFHospedaje frmHo = new JIFHospedaje();
            frmH.getJdpEscritorio().add(frmHo);
            //Llamado al controlador JInternal
            ControladorJIFHos ctrlFrmHo = new ControladorJIFHos(frmHo);
            ctrlFrmHo.iniciar();
        }
        if (e.getSource().equals(frmH.getMnuDatosUs()) || e.getSource().equals(frmH.getBtnDatosUs())) {
            JIFDatosUsuario frmUs = new JIFDatosUsuario();
            frmH.getJdpEscritorio().add(frmUs);
            //Llamado al controlador JInternal
            ControladorJIFUs ctrlFrmU = new ControladorJIFUs(frmUs);
            ctrlFrmU.iniciar();
        }
        

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author A n d r e s
 */
public class ControladorJIFUs implements ActionListener {

    private Factura objF;
    private JIFDatosUsuario frmU;

    public ControladorJIFUs() {
        this.objF = new Factura();
        this.frmU = new JIFDatosUsuario();
        this.frmU.getBtnRegistrarUs().addActionListener(this);

    }

    public ControladorJIFUs(JInternalFrame form) {
        this.objF = new Factura();
        this.frmU = (JIFDatosUsuario) form;
        this.frmU.getBtnRegistrarUs().addActionListener(this);

    }

    public void iniciar() {
        frmU.setTitle("Datos Usuario");
        frmU.setVisible(true);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (frmU.getBtnRegistrarUs() == e.getSource()) {
                objF.getCliente().setNombre(frmU.getTxtNombre().getText());
                objF.getCliente().setId(frmU.getTxtId().getText());
                objF.getCliente().setTel(frmU.getTxtTel().getText());
            }

        } catch (NumberFormatException ex) {
            String[] valErr = ex.toString().split(":");
            JOptionPane.showMessageDialog(frmU, "ERROR AL INGRESAR EL DATO " + valErr[2]
                                                          + "Se requiere un dato NUMERICO");
        }
    }
}

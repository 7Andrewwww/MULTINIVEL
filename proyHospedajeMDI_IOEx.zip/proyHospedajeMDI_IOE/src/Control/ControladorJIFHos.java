/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author A n d r e s
 */
public class ControladorJIFHos implements ActionListener {

    private Factura objF;
    private JIFHospedaje frmH;

    public ControladorJIFHos() {
        this.objF = new Factura();
        this.frmH = new JIFHospedaje();
        this.frmH.getBtnRegistrarHo().addActionListener(this);
        this.frmH.getBtnGrupo().add(frmH.getRbtnGlamping());
        this.frmH.getBtnGrupo().add(frmH.getRbtnHabitacion());

    }

    public ControladorJIFHos(JInternalFrame form) {
        this.objF = new Factura();
        this.frmH = (JIFHospedaje) form;  //this.frmA = (jIFRMVehiculo) form;
        this.frmH.getBtnRegistrarHo().addActionListener(this);
        this.frmH.getBtnGrupo().add(frmH.getRbtnGlamping());
        this.frmH.getBtnGrupo().add(frmH.getRbtnHabitacion());

    }

    public void iniciar() {
        frmH.setTitle("Datos Hospedaje");
        frmH.setVisible(true);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (frmH.getBtnRegistrarHo() == e.getSource() && frmH.getRbtnGlamping().isSelected()) {
                Camping objC = new Camping();
                objC.setCanDia(Integer.parseInt(frmH.getTxtNoches().getText()));
                objC.setNumPer(Integer.parseInt(frmH.getTxtPersonas().getText()));
                frmH.getTxtaResp().append(objC.toString() + objF.valorTotal());
            }

            if (frmH.getBtnRegistrarHo() == e.getSource() && frmH.getRbtnHabitacion().isSelected()) {
                Habitacion objH = new Habitacion();
                objH.setCanDia(Integer.parseInt(frmH.getTxtNoches().getText()));
                objH.setNumPer(Integer.parseInt(frmH.getTxtPersonas().getText()));
                frmH.getTxtaResp().append(objH.toString() + objF.valorTotal());
            }

        } catch (NumberFormatException ex) {
            String[] valErr = ex.toString().split(":");
            JOptionPane.showMessageDialog(frmH, "ERROR AL INGRESAR EL DATO " + valErr[2]
                                                          + "Se requiere un dato NUMERICO");
        }
    }
}

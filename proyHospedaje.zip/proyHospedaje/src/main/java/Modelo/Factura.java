/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public class Factura {

    double IVA;
    Fecha objF;
    Hospedaje objH;
    Cliente objC;

    public Factura(double IVA, Fecha objF, Hospedaje objH, Cliente objC) {
        this.IVA = IVA;
        this.objF = objF;
        this.objH = objH;
        this.objC = objC;
    }

    public Factura() {
        this.IVA = 0;
        this.objF = new Fecha();
        this.objC = new Cliente();
    }

    public double getIVA() {
        return IVA;
    }

    public void setIVA(double IVA) {
        this.IVA = IVA;
    }

    public Fecha getObjF() {
        return objF;
    }

    public void setObjF(Fecha objF) {
        this.objF = objF;
    }

    public Hospedaje getObjH() {
        return objH;
    }

    public void setObjH(Hospedaje objH) {
        this.objH = objH;
    }

    public Cliente getObjC() {
        return objC;
    }

    public void setObjC(Cliente objC) {
        this.objC = objC;
    }
    
    public double valorTotal(){
        return objH.valorPagar()*IVA;
    }

    @Override
    public String toString() {
        return "Factura{" + "IVA=" + IVA + ", objF=" + objF + ", objH=" + objH + ", objC=" + objC + '}';
    }
    

}

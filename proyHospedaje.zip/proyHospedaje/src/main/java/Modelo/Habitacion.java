/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public class Habitacion extends Hospedaje {

    // Constructor
    public Habitacion(int canDia, int numPer, double precio) {
        super(canDia, numPer, precio);
        this.fechin = new Fecha();
    }

    @Override
    public double valorPagar() {
        return canDia * descuento();
    }

    @Override
    public double descuento() {
        if (numPer > 2) {
            return precio = 30000;
        } else {
            return precio = 20000;
        }
    }

    @Override
    public String toString() {
        return "Habiatcion{"
                + "canDia=" + canDia
                + ", numPer=" + numPer
                + ", precio=" + precio
                + "fechin=" + fechin
                + +'}';
    }

}

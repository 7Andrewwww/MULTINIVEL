/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public class Cliente {
    private String id, nombre, tel;

    public Cliente() {
        this.id = "";
        this.nombre = "";
        this.tel = "";

    }

    public Cliente(String id, String nombre, String tel, Fecha fNac) {
        this.id = id;
        this.nombre = nombre;
        this.tel = tel;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public String toString() {
        return "\n Identificaion: " + id + "\n Nombre: " + nombre + "\n Telefono: " + tel;
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Main;

/**
 *
 * @author A n d r e s
 */
public class ProyHospedaje {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

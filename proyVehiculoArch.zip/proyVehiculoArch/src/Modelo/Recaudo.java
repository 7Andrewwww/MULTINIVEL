/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class Recaudo {

    private ArrayList<Formulario> listaF;

    public Recaudo(ArrayList<Formulario> listaF) {
        this.listaF = listaF;
    }

    public Recaudo() {
        this.listaF = new ArrayList<Formulario>();
    }

    public ArrayList<Formulario> getListaF() {
        return listaF;
    }

    public void setListaF(ArrayList<Formulario> listaF) {
        this.listaF = listaF;
    }

    public double totalRecaudo() {
        double padoFormulario = 0;
        for (Formulario formulario : listaF) {
            padoFormulario += formulario.valorPago();
        }
        return padoFormulario;
    }

    public int cantidadAutos() {
        int contA = 0;
        for (Formulario formulario : listaF) { //Cada Formulario de Recaudo
            for (Vehiculo objV : formulario.getListaV()) { //Lista de Vehiculos
                if (objV instanceof Moto) {
                    contA++;
                }
            }
        }
        return contA;
    }

    public int cantidadMotos() {
        int contM = 0;
        for (Formulario formulario : listaF) { //Cada Formulario de Recaudo
            for (Vehiculo objV : formulario.getListaV()) { //Lista de Vehiculos
                if (objV instanceof Moto) {
                    contM++;
                }
            }
        }
        return contM;
    }

    @Override
    public String toString() {
        String datos = "\n";
        for (Formulario formulario : listaF) {
            datos += formulario.toString() + "\n___________\n";
        }
        return "\nListado Formulario = " + datos;
    }

}

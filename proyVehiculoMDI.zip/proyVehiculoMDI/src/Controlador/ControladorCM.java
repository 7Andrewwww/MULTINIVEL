/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.CajasMensaje;

/**
 *
 * @author Estudiante
 */
public class ControladorCM {

    private CajasMensaje ent;
    private Formulario objF;

    public ControladorCM() {
        this.ent = new CajasMensaje();
        this.objF = new Formulario();
    }

    public void iniciar() {
        ent.setTitulo("Programa Impuesto Vehiculo ");

        do {
            //Datos propietario
            ent.setTitulo("Datos del Propietario: \n");
            objF.getPropietario().setId(ent.leerTexto("Identificacion: "));
            objF.getPropietario().setNombre(ent.leerTexto("Nombre: "));
            objF.getPropietario().setTel(ent.leerTexto("Telefono: "));
            String fecha[] = ent.leerTexto("Fecha de nacimiento: (dd/mm/aa)").split("/");
            objF.getPropietario().setfNac(new Fecha(Integer.parseInt(fecha[0]),
                    Integer.parseInt(fecha[1]),
                    Integer.parseInt(fecha[2])));
            do {

                int tipoV = ent.leerEntero("Ingrese el tipo de Vehículo\n1.Auto\n2.Moto");
                //Datos vehiculo
                switch (tipoV) {
                    case 1 -> {
                        Auto objA = new Auto();
                        //objF.setListaV(new Auto());
                        //Datos Auto
                        ent.setTitulo("Datos de la moto");
                        objA.setMarca(ent.leerTexto("Marca: "));
                        objA.setPlaca(ent.leerTexto("Placa: "));
                        objA.setTipo(ent.leerTexto("Tipo: "));
                        objA.setModelo(ent.leerEntero("Modelo: "));
                        objA.setValor(ent.leerDouble("Valor: "));
                        objF.getListaV().add(objA);
                        break;
                    }
                    case 2 -> {
                        Moto objM = new Moto();
                        //objF.setListaV(new Moto());
                        //Datos Auto
                        ent.setTitulo("Datos de la moto");
                        objM.setCilindraje(ent.leerEntero("Cilindraje: "));
                        objM.setMarca(ent.leerTexto("Marca: "));
                        objM.setPlaca(ent.leerTexto("Placa: "));
                        objM.setTipo(ent.leerTexto("Tipo: "));
                        objM.setModelo(ent.leerEntero("Modelo: "));
                        objM.setValor(ent.leerDouble("Valor: "));
                        objF.getListaV().add(objM);
                        break;
                    }
                }

            } while (ent.validar("Desea ingresar otro Vehiculo? s/n"));
            ent.mostrar(objF.toString() + "\nTotal Pago= " + objF.valorPago());
        } while (ent.validar("Desea ingresar otro Formulario"));
    }
}

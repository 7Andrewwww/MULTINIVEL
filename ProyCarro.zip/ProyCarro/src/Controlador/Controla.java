/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import proycarro.modelo.Carro;
import vista.Entrada;

/**
 *
 * @author A n d r e s
 */
public class Controla {
    private Carro cr;
    private Entrada ent;
    
    public Controla()
    {
        this.cr = new Carro();
        this.ent = new Entrada();
    }
    public void Iniciar()
    {
        ent.Mostar("...PROGRAMA IMPUESTO VEHICULO...");
        cr.setMarca(ent.leerTexto("Marca :"));
        cr.setColor(ent.leerTexto("Color :"));
        cr.setModelo(ent.leerEntero("Modelo :"));
        cr.setValor(ent.leerDecimal("Valor :"));
        ent.Mostar(cr.toString() + " \n Impuesto :"  + cr.impuesto());
    }
}


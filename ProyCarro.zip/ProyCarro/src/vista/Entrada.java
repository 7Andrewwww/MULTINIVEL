/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.Scanner;

/**
 *
 * @author A n d r e s
 */
public class Entrada {

    private Scanner ent;

    public Entrada(Scanner ent) {
        this.ent = ent;
    }

    public Entrada() {
        this.ent = new Scanner(System.in);
    }

    public String leerTexto(String msg) {
        System.out.println(msg);
        return ent.next();
    }

    public int leerEntero(String msg) {
        System.out.println(msg);
        return ent.nextInt();
    }

    public double leerDecimal(String msg) {
        System.out.println(msg);
        return ent.nextDouble();
    }

    public void Mostar(String msg) {
        System.out.println(msg);
    }

}

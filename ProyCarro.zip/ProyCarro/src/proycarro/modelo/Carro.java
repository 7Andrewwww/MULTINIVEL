/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proycarro.modelo;

/**
 *
 * @author A n d r e s
 */
public class Carro {

    public int modelo;
    public double valor;
    public String color, marca;

    public Carro(int modelo, String color, String marca) {
        this.modelo = modelo;
        this.color = color;
        this.marca = marca;
    }

    public Carro() {
        this.modelo = 0;
        this.color = "";
        this.marca = "";
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return """
               Datos Estudiante...
                Marca: """ + marca + " \n Color : " + color + " \n Modelo : " + modelo + " \n Valor : " + valor;
    }

    public double impuesto() {
        int año = 1990;
        if (modelo < año) {
            valor = valor * 0.10;
        } else {
            valor = valor * 0.05;
        }
        return valor;
    }
}

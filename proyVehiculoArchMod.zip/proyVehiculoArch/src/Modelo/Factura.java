/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class Factura {
    private String CodF;
    private Fecha fN;
    private Persona Propietario;
    private ArrayList <Vehiculo> listaV;

    public Factura(String CodF, Fecha fN, Persona Propietario, Vehiculo objV) {
        this.CodF = CodF;
        this.fN = fN;
        this.Propietario = Propietario;
        this.listaV = listaV;
    }
    
      public String getCodF() {
        return CodF;
    }

    public void setCodF(String CodF) {
        this.CodF = CodF;
    }

    public Fecha getfN() {
        return fN;
    }

    public void setfN(Fecha fN) {
        this.fN = fN;
    }

    public Persona getPropietario() {
        return Propietario;
    }

    public void setPropietario(Persona Propietario) {
        this.Propietario = Propietario;
    }

    public ArrayList<Vehiculo> getListaV() {
        return listaV;
    }

    public void setListaV(ArrayList<Vehiculo> listaV) {
        this.listaV = listaV;
    }

    
     public Factura(int tipoV) {
        this.CodF =""+Math.random()*999;
        this.fN = new Fecha();
        this.Propietario = new Persona();
        switch(tipoV){
            case 1:
               this.listaV.add(new Auto());
               break;
            case 2:
                this.listaV.add(new Moto());
                break;
        }
     }
            public Factura() {
        this.CodF =""+Math.random()*999;
        this.fN = new Fecha();
        this.Propietario = new Persona();
        this.listaV= new ArrayList<Vehiculo>();
        }
       public double valorPago(){
         double pagoImpuestos=0;
         for (Vehiculo objV : listaV) {
                     pagoImpuestos+= objV.impuesto();
         }
         return pagoImpuestos;
     }
     public String datos(){
         String lista="";
         for (Vehiculo objV : listaV) {
             lista+= objV.toString()+
                     "\n Impuesto: "+objV.impuesto();
         }
         return lista;
     }
     public Object[] Registro(){
         int posReg=this.getListaV().size()-1;
         String tipo="";
         if(this.getListaV().get(posReg)instanceof Auto){
             tipo="Auto";
         }else
             tipo="Moto";
         
         
         Object[] reg={this.CodF,this.fN.toString(),
                      this.getPropietario().getId(),
                      tipo,
                      this.getListaV().get(posReg).getPlaca(),
                      this.getListaV().get(posReg).impuesto()
                      };
         return reg;
     }
     public String DatosF(){
         int posReg=this.getListaV().size()-1;
         String tipo="";
         if(this.getListaV().get(posReg)instanceof Auto){
             tipo="Auto";
         }else
             tipo="Moto";
         
         
         return this.CodF+ ";" +this.fN.toString()+ ";" +
                      this.getPropietario().getId()+ ";" +
                      tipo+ ";" +
                      this.getListaV().get(posReg).getPlaca()+ ";" +
                      this.getListaV().get(posReg).impuesto();
     }
    @Override
    public String toString() {
        return " Datos Factura \n Codigo Factura: " + CodF +
               "\n Fecha factura: " + fN.toString() + 
               "\n Propietario: " + Propietario.toString() + 
               "\n Lista Vehiculos: \n" + datos();
    }
    
    
}

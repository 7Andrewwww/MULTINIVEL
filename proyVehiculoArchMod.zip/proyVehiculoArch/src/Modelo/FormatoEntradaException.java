/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author USER
 */
public class FormatoEntradaException extends Exception {
    private int NroErr;
    private String msg;
    
    public FormatoEntradaException(int NroErr, String dato) {
        this.NroErr = NroErr;
        switch (NroErr) {
            case 101: {
                msg = "Se ha detectado Valor Nulo...";
                break;
            }
            case 102: {
                msg = "Solo se admiten letras...";
                break;
            }
            case 103: {
                msg = "Solo se admiten números...";
                break;
            }
            case 104: {
                msg = "Solo se admiten 6 caracteres...";
                break;
            }
        }
        msg += " en dato: " + dato;
    }
    
    public FormatoEntradaException() {
        this.NroErr = 101;
        this.msg = "Error generado por formato";
    }
    
    @Override
    public String toString() {
        return "Error: " + NroErr + " generado por: " + msg;
    }
    
    public int getNroErr() {
        return NroErr;
    }
    
    public void setNroErr(int NroErr) {
        this.NroErr = NroErr;
    }
    
    public String getMsg() {
        return msg;
    }
    
    public void setMsg(String msg) {
        this.msg = msg;
    }
}


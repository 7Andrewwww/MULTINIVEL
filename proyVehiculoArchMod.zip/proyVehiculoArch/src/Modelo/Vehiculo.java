/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public abstract class Vehiculo {

    protected String placa, marca, tipo;
    protected int modelo;
    protected double valor;

    public Vehiculo(String placa, String marca, int modelo, double valor) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.valor = valor;
    }

    public Vehiculo() {
        this.placa = "";
        this.marca = "";
        this.modelo = 0;
        this.valor = 0;
    }

    DecimalFormat  df = new DecimalFormat("#,###");
    @Override
    public String toString() {
        return  "Placa= " + placa
                + "\n Marca: " + marca
                + "\n Modelo: " + modelo
                + "\n Valor: " +df.format(valor);
    }
    
    public abstract String datosArch();

    public abstract double impuesto();

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) throws FormatoEntradaException {
    Pattern pat = Pattern.compile("^[a-zA-Z0-9]{1,6}$"); // Expresión regular para 1 a 6 dígitos
    Matcher mat = pat.matcher(placa);
    if (placa.equals("")) {
        throw new FormatoEntradaException(101, "Placa: ");
    } else if (!mat.matches()) {
        throw new FormatoEntradaException(104, "placa: ");
    } else {
        this.placa = placa;}
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class Recaudo {

    private ArrayList<Factura> listaF;

    public Recaudo(ArrayList<Factura> listaF) {
        this.listaF = listaF;
    }

    public Recaudo() {
        this.listaF = new ArrayList<Factura>();
    }

    public ArrayList<Factura> getListaF() {
        return listaF;
    }

    public void setListaF(ArrayList<Factura> listaF) {
        this.listaF = listaF;
    }

    public double totalRecaudo() {
        double padoFormulario = 0;
        for (Factura formulario : listaF) {
            padoFormulario += formulario.valorPago();
        }
        return padoFormulario;
    }

    public int cantidadAutos() {
        int contA = 0;
        for (Factura formulario : listaF) { 
            for (Vehiculo objV : formulario.getListaV()) { 
                if (objV instanceof Moto) {
                    contA++;
                }
            }
        }
        return contA;
    }

    public int cantidadMotos() {
        int contM = 0;
        for (Factura formulario : listaF) { 
            for (Vehiculo objV : formulario.getListaV()) { 
                if (objV instanceof Moto) {
                    contM++;
                }
            }
        }
        return contM;
    }

    @Override
    public String toString() {
        String datos = "\n";
        for (Factura formulario : listaF) {
            datos += formulario.toString() + "\n___________\n";
        }
        return "\nListado Formulario = " + datos;
    }

}

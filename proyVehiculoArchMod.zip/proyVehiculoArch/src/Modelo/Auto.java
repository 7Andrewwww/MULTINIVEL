/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class Auto extends Vehiculo {

    @Override
    public double impuesto() {
        if (modelo > 1990) {
            return this.valor * 0.05;
        } else {
            return this.valor * 0.10;
        }
    }


    public Auto(String placa, String marca, int modelo, double valor) {
        super(placa, marca, modelo, valor);
    }

    public Auto() {
        super();
    }

    @Override
    public String datosArch() {
        return "Auto;" + placa + ";" + marca + ";" +
                modelo + ";" + 0 + ";" + valor;
    }

    
}

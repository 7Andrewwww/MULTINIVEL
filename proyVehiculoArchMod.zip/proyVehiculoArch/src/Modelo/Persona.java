/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Calendar;
import java.util.Date;
import java.util.regex.*;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class Persona {
    private String id, nombre, tel;
    private Fecha fNac;
    
    public Persona() {
        this.id = "";
        this.nombre = "";
        this.tel = "";
        this.fNac = new Fecha();
    }

    public Persona(String id, String nombre, String tel, Fecha fNac, Date fecha) {
        this.id = id;
        this.nombre = nombre;
        this.tel = tel;
        this.fNac = fNac;
    }
   
    public String getId() {
        return id;
    }

    public void setId(String id) throws FormatoEntradaException{
        Pattern pat= Pattern.compile("[abc|ABC]");
        Matcher mat= pat.matcher(id);
        if(id.equals(""))
            throw new FormatoEntradaException(101, "Id: ");
        else if(mat.find()){
            throw new FormatoEntradaException(103, "Id: ");
        }else{
        this.id = id;}
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws FormatoEntradaException{
        Pattern pat= Pattern.compile("[1-9]");
        Matcher mat= pat.matcher(nombre);
        if(id.equals(""))
            throw new FormatoEntradaException(101, "Nombre: ");
        else if(mat.find()){
            throw new FormatoEntradaException(102, "Nombre: ");
        }else{
        this.nombre = nombre;}
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) throws FormatoEntradaException{
        Pattern pat= Pattern.compile("[abc|ABC]");
        Matcher mat= pat.matcher(tel);
        if(id.equals(""))
            throw new FormatoEntradaException(101, "Teléfono: ");
        else if(mat.find()){
            throw new FormatoEntradaException(103, "Teléfono: ");
        }else{
        this.tel = tel;}
    }

    public Fecha getfNac() {
        return fNac;
    }

    public void setfNac(Fecha fNac) {
        this.fNac = fNac;
    }
    
    public int edad(){
        Calendar fecha= Calendar.getInstance();
        return fecha.get(Calendar.YEAR)-fNac.getAa();
    }

    @Override
    public String toString() {
        return  "\n id=" + id + "\n Nombre=" + nombre + "\n Telefono=" + tel + "\n Nacimiento=" + fNac.toString();
    }
    public String datosP() {
        return  nombre + ";" + id + ";" +
                tel + ";" + fNac.toString();
    }

    
}

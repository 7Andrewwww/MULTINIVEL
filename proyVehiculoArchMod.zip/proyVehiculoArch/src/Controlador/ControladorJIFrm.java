/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.jIfrmVehiculo;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class ControladorJIFrm  implements ActionListener{

    private jIfrmVehiculo frmA;
    private Factura objF;
    private Recaudo objR;
    private Conexion con;
    private Vehiculo objV;

    public ControladorJIFrm() {
        this.objR = new Recaudo();
        this.frmA = new jIfrmVehiculo();
        this.objF = new Factura();
        this.con = new Conexion();
        this.frmA.getBtnAgregarV().addActionListener(this);
        this.frmA.getBtnRegistrar().addActionListener(this);
        this.frmA.getBtngrupo().add(frmA.getRbtnAuto());
        this.frmA.getBtngrupo().add(frmA.getRbtnMoto());
        this.frmA.getRbtnAuto().addActionListener(this);
        this.frmA.getRbtnMoto().addActionListener(this);
        SpinnerNumberModel spModelo = new SpinnerNumberModel(1990,1990,2010,1);
        frmA.getSpnModelo().setModel(spModelo);
    }
    
    public ControladorJIFrm(JInternalFrame form, Recaudo objR){//recibe Jinternal desde MDI
        this.objR = objR;
        this.frmA = (jIfrmVehiculo) form;
        this.objF = new Factura();
        this.con = new Conexion();
        this.frmA.getBtnAgregarV().addActionListener(this);
        this.frmA.getBtnRegistrar().addActionListener(this);
        this.frmA.getBtngrupo().add(frmA.getRbtnAuto());
        this.frmA.getBtngrupo().add(frmA.getRbtnMoto());
        this.frmA.getRbtnAuto().addActionListener(this);
        this.frmA.getRbtnMoto().addActionListener(this);
        SpinnerNumberModel spModelo = new SpinnerNumberModel(1990,1990,2010,1);
        frmA.getSpnModelo().setModel(spModelo);
    }

    public void agregarVehiculo(JTable tabla, Factura formV){
        DefaultTableModel plantilla= (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.Registro());
    }
    public void iniciarControles (Component [] controles) {
    int cantTab=0;
    for (Component control : controles) {
        cantTab++;
        if (control instanceof JTabbedPane) {
            cantTab=((JTabbedPane) control).getTabCount();
            for (int i = 0; i < cantTab; i++) {
                Component panel= ((JTabbedPane) control).getComponent (i);
                if (panel instanceof JPanel) {
                    iniciarControles ( ((JPanel) panel).getComponents() );
                }
            }
        } if (control instanceof JPanel) {
            iniciarControles ( ((JPanel) control).getComponents() );
        } if (control instanceof JTextField) {
            ((JTextField) control) .setText ("" );
        } if (control instanceof JTable) {
            iniciarTabla ((JTable) control); 
        }
    }
}
public void iniciarTabla (JTable tabla) {
    DefaultTableModel Model= (DefaultTableModel) tabla.getModel();
    Model.setRowCount(0);
    tabla.repaint();
}    
/*public void iniciarTabla (JTable tabla) {
   DefaultTableModel Model= (DefaultTableModel) tabla.getModel();
        for (int i = tabla.getRowCount() - 1 ; i >= 0; i--) {
            Model.removeRow(i);
        }
        tabla.repaint();
}*/


    
    @Override
    public void actionPerformed(ActionEvent e) {
        //control
    if (e.getSource() instanceof JRadioButton) {
        if (frmA.getRbtnAuto().isSelected()) {
            frmA.getPnlCil().setVisible(false);
        } else if (frmA.getRbtnMoto().isSelected()) {
            frmA.getPnlCil().setVisible(true);
        }
    }
    if (e.getSource().equals(frmA.getBtnAgregarV())){
        try{
        if (frmA.getRbtnAuto().isSelected()) {
            Auto objA= new Auto();
            objA.setPlaca(frmA.getTxtPlaca().getText());
            objA.setMarca(frmA.getTxtMarca().getText());
            objA.setModelo(Integer.parseInt(frmA.getSpnModelo().getValue().toString()));
            //objA.setModelo(Integer.parseInt(frmA.getSpnModelo().getName()));
            objA.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
            objF.getListaV().add(objA);
              objF.getPropietario().setId(frmA.getTxtId().getText());
         objF.getPropietario().setNombre(frmA.getTxtNom().getText());
         objF.getPropietario().setTel(frmA.getTxtTel().getText());
            SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            String fecha= df.format(frmA.getDcFecha().getDate());
            String[] aFecha= fecha.split("/");
            objF.getPropietario().setfNac(new Fecha(Integer.parseInt(aFecha[0]),
                                                    Integer.parseInt(aFecha[1]),
                                                    Integer.parseInt(aFecha[2])));
            con.EscribeDatos("vehiculos.txt", objA.datosArch());
            con.EscribeDatos("propietarios.txt", objF.getPropietario().datosP());
            con.EscribeDatos("facturas.txt", objF.DatosF());
        } else if (frmA.getRbtnMoto().isSelected()) {
            Moto objM= new Moto();
            objM.setPlaca(frmA.getTxtPlaca().getText());
            objM.setMarca(frmA.getTxtMarca().getText());
            objM.setModelo(Integer.parseInt(frmA.getSpnModelo().getValue().toString()));
            objM.setCilindraje(Integer.parseInt(frmA.getTxtCil().getText()));
            objM.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
            objF.getListaV().add(objM);
              objF.getPropietario().setId(frmA.getTxtId().getText());
         objF.getPropietario().setNombre(frmA.getTxtNom().getText());
         objF.getPropietario().setTel(frmA.getTxtTel().getText());
         SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            String fecha= df.format(frmA.getDcFecha().getDate());
            String[] aFecha= fecha.split("/");
            objF.getPropietario().setfNac(new Fecha(Integer.parseInt(aFecha[0]),
                                                    Integer.parseInt(aFecha[1]),
                                                    Integer.parseInt(aFecha[2])));
         con.EscribeDatos("vehiculos.txt", objM.datosArch());
         con.EscribeDatos("propietarios.txt", objF.getPropietario().datosP());
         con.EscribeDatos("facturas.txt", objF.DatosF());
        }
        
        agregarVehiculo(frmA.getTblDatos(), objF);
        frmA.getSpnModelo().setValue(1990);
        }catch(NumberFormatException err){
        String []valErr = err.toString().split(":");
        JOptionPane.showMessageDialog( frmA, "Error: al ingresar el dato " + valErr[2] +
                                             "\nse requiere un dato numérico....");
        
        } catch (FormatoEntradaException ex) {
            JOptionPane.showMessageDialog(frmA, ex.toString());
        } catch (IOException ex) {
            Logger.getLogger(ControladorJIFrm.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //boton registrar
    if (e.getSource() == frmA.getBtnRegistrar()) {   
        //iniciarControles(frmA.getContentPane().getComponents());
        ArchPdf arch= new ArchPdf();
        arch.crear_PDF(objF);
        objR.getListaF().add(objF);
        iniciarControles(frmA.getContentPane().getComponents());
        iniciarTabla(frmA.getTblDatos());
    }
}
    
    public void iniciar() {
        frmA.setTitle("Registro Auto");
        frmA.getPnlCil().setVisible(false);
        frmA.setVisible(true);   
    }
    
}

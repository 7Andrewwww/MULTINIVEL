/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.jIfrmConsulta;
import Vista.jIfrmVehiculo;
import Vista.mdiInicio;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class ControladorMdi implements ActionListener{

    private mdiInicio frmI;
    private Recaudo objR;

    public ControladorMdi() {
        this.frmI = new mdiInicio();
        this.objR = new Recaudo();
        //Menu
        this.frmI.getMnuNuevoF().addActionListener(this);
        this.frmI.getMnuSalir().addActionListener(this);
        this.frmI.getMnuConsultaR().addActionListener(this);
        //Barra herramientas
        this.frmI.getBtnNuevoF().addActionListener(this);
        this.frmI.getBtnRecaudo().addActionListener(this);
        this.frmI.getBtnSalir().addActionListener(this);
    }
    public void iniciar() {
        frmI.setTitle("Registro Auto");
        frmI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmI.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frmI.setVisible(true);
    }

    public void agregarArchTabla(JTable tabla){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con= new Conexion();
        try{
          String [] registros = con.leerDatos("vehiculos.txt").split("\n");
        for (String registro: registros){
            String []linea=registro.split(";");
            Object reg []={linea[0],linea[1],linea[2],linea[3],
                        linea[4],linea[5]};
            plantilla.addRow(reg);
        } 
        }catch(IOException err){
            JOptionPane.showMessageDialog(frmI, "Error en apertura de archivos...");
        }  
    }
    public void agregarArchTablaF(JTable tabla){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con= new Conexion();
        try{
          String [] registros = con.leerDatos("facturas.txt").split("\n");
        for (String registro: registros){
            String []linea=registro.split(";");
            Object reg []={linea[0],linea[1],linea[2],linea[3],
                        linea[4],linea[5]};
            plantilla.addRow(reg);
        } 
        }catch(IOException err){
            JOptionPane.showMessageDialog(frmI, "Error en apertura de archivos...");
        }  
    }
    public void agregarArchTablaP(JTable tabla){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con= new Conexion();
        try{
          String [] registros = con.leerDatos("propietarios.txt").split("\n");
        for (String registro: registros){
            String []linea=registro.split(";");
            Object reg []={linea[0],linea[1],linea[2],linea[3]};
            plantilla.addRow(reg);
        } 
        }catch(IOException err){
            JOptionPane.showMessageDialog(frmI, "Error en apertura de archivos...");
        }  
    }
    
    /*public void agregarArchTablap(JTable tabla){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con= new Conexion();
        try{
          String [] registrosP = con.leerDatosP("propietarios.txt").split("\n");
        for (String registro: registrosP){
            String []linea=registro.split(";");
            Object reg []={linea[0],linea[1],linea[2],linea[3]};
            plantilla.addRow(reg);
        } 
        }catch(IOException err){
            JOptionPane.showMessageDialog(frmI, "Error en apertura de archivos...");
        }  
    }
    public void agregarArchTablaf(JTable tabla){
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con= new Conexion();
        try{
          String [] registrosP = con.leerDatosF("facturas.txt").split("\n");
        for (String registro: registrosP){
            String []linea=registro.split(";");
            Object reg []={linea[0],linea[1],linea[2],linea[3],
                        linea[4],linea[5]};
            plantilla.addRow(reg);
        } 
        }catch(IOException err){
            JOptionPane.showMessageDialog(frmI, "Error en apertura de archivos...");
        }  
    }*/
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(frmI.getMnuSalir())||
           e.getSource().equals(frmI.getBtnSalir())){
            int resp = JOptionPane.showConfirmDialog(frmI, "¿Desea Terminar Ejecucion?");
            if(resp == JOptionPane.YES_OPTION){
                frmI.dispose();
            }
        }
        if(e.getSource().equals(frmI.getMnuConsultaR())||
           e.getSource().equals(frmI.getBtnRecaudo())){
            jIfrmConsulta frmC= new jIfrmConsulta();
            frmI.getJpdEscritorio().add(frmC);
            agregarArchTabla(frmC.getTblDatosV());
            agregarArchTablaP(frmC.getTblDatosP());
            agregarArchTablaF(frmC.getTblDatosF());
            frmC.setVisible(true);
            ControladorJIConsultas ctrlFrmC= new ControladorJIConsultas (frmC,objR);
            ctrlFrmC.iniciar();
        }
        if(e.getSource().equals(frmI.getMnuNuevoF())||
           e.getSource().equals(frmI.getBtnNuevoF())){
            jIfrmVehiculo frmA= new jIfrmVehiculo();
            frmI.getJpdEscritorio().add(frmA);
            //llamado al controlador JInternal
            ControladorJIFrm ctrlFrmA= new ControladorJIFrm (frmA,objR);
            ctrlFrmA.iniciar();
        }
    }

    
}

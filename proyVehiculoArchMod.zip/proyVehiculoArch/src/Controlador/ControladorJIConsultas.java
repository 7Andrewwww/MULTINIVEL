/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristian Velasco Delbasto
 */
public class ControladorJIConsultas  implements ActionListener{

    private jIfrmConsulta frmC;
    private Factura objF;
    private Recaudo objR;

    public ControladorJIConsultas() {
        this.objR = new Recaudo();
        this.frmC = new jIfrmConsulta();
        this.objF = new Factura();
        this.frmC.getBtnBuscar().addActionListener(this);
    }
    
    public ControladorJIConsultas(JInternalFrame form, Recaudo objR){//recibe Jinternal desde MDI
        this.objR = objR;
        this.frmC = (jIfrmConsulta) form;
        this.objF = new Factura();
        this.frmC.getBtnBuscar().addActionListener(this);
    }

    
    public void iniciarControles (Component [] controles) {
    int cantTab=0;
    for (Component control : controles) {
        cantTab++;
        if (control instanceof JTabbedPane) {
            cantTab=((JTabbedPane) control).getTabCount();
            for (int i = 0; i < cantTab; i++) {
                Component panel= ((JTabbedPane) control).getComponent (i);
                if (panel instanceof JPanel) {
                    iniciarControles ( ((JPanel) panel).getComponents() );
                }
            }
        } if (control instanceof JPanel) {
            iniciarControles ( ((JPanel) control).getComponents() );
        } if (control instanceof JTextField) {
            ((JTextField) control) .setText ("" );
        } if (control instanceof JTable) {
            iniciarTabla ((JTable) control); 
        }
    }
}
public void iniciarTabla (JTable tabla) {
    DefaultTableModel Model= (DefaultTableModel) tabla.getModel();
    Model.setRowCount(0);
    tabla.repaint();
}    
/*public void iniciarTabla (JTable tabla) {
   DefaultTableModel Model= (DefaultTableModel) tabla.getModel();
        for (int i = tabla.getRowCount() - 1 ; i >= 0; i--) {
            Model.removeRow(i);
        }
        tabla.repaint();
}*/



    
    @Override
    public void actionPerformed(ActionEvent e) {
        //Boton Buscar
    if (e.getSource().equals(frmC.getBtnBuscar())) {
        JOptionPane.showMessageDialog(frmC, objR.toString());
    }
}
    

    public void iniciar() {
        frmC.setTitle("Consulta Recaudo");
        frmC.setLocation(50,10);
        frmC.setVisible(true);   
    }
}

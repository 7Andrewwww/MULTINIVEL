/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Ingrid Rubio
 */
public abstract class Vehiculo {

    protected String placa, marca, tipo;
    protected int modelo;
    protected double valor;

    public Vehiculo(String placa, String marca, String tipo, int modelo, double valor) {
        this.placa = placa;
        this.marca = marca;
        this.tipo = tipo;
        this.modelo = modelo;
        this.valor = valor;
    }

    public Vehiculo() {
        this.placa = "";
        this.marca = "";
        this.tipo = "";
        this.modelo = 0;
        this.valor = 0;
    }

    @Override
    public String toString() {
        return "Datos vehiculo: \n"
                + "Placa= " + placa
                + "\n Marca: " + marca
                + "\n Tipo: " + tipo
                + "\n Modelo: " + modelo
                + "\n Valor: " + valor;
    }

    public abstract double impuesto();

    /*public double Impuesto(){
        
        if(modelo>1990){
            return this.valor*0.05;
        }
        else {
            return this.valor*0.10;
        }
    }*/
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.Tabla2;
import Vista.frmVehiculo;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Estudiante
 */
public class ControladorFrm implements ActionListener {

    private frmVehiculo frmA;
    private Tabla2 tabla2;
    private Formulario objF;

    public ControladorFrm() {
        this.frmA = new frmVehiculo();
        this.objF = new Formulario();
        this.frmA.getBtnRegistrar().addActionListener(this);//sensor boton
        this.frmA.getCmbTipoV().addActionListener(this);
        this.frmA.getBtnAgregarV().addActionListener(this);
        this.frmA.getBtnForm().addActionListener(this);
    }

    public void iniciar() {
        frmA.setTitle("Registro Autos");
        frmA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmA.setLocationRelativeTo(null);
        frmA.getPnlCil().setVisible(false);
        frmA.setVisible(true);
    }

    public void agregarVehiculo(JTable tabla, Formulario formV) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.registro());
    }

    public void transferirDatosTabla(JTable tabla1, JTable tabla2) {
        DefaultTableModel modeloOrigen = (DefaultTableModel) tabla1.getModel();
        DefaultTableModel modeloDestino = (DefaultTableModel) tabla2.getModel();

        // Limpiar la tabla de destino antes de transferir los datos para evitar duplicados
        modeloDestino.setRowCount(0);

        // Recorrer cada fila de la tabla origen y agregarla a la tabla destino
        for (int i = 0; i < modeloOrigen.getRowCount(); i++) {
            Object[] fila = new Object[modeloOrigen.getColumnCount()];
            for (int j = 0; j < modeloOrigen.getColumnCount(); j++) {
                fila[j] = modeloOrigen.getValueAt(i, j);
            }
            modeloDestino.addRow(fila);
        }
         modeloOrigen.setRowCount(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmA.getCmbTipoV())) {
            switch (frmA.getCmbTipoV().getSelectedIndex()) {
                case 0 -> {
                    frmA.getPnlCil().setVisible(false);
                }
                case 1 -> {
                    frmA.getPnlCil().setVisible(true);
                }
            }
        }

        if (e.getSource().equals(frmA.getBtnAgregarV())) {
            switch (frmA.getCmbTipoV().getSelectedIndex()) {
                case 0 -> {
                    Auto objA = new Auto();
                    objA.setMarca(frmA.getTxtMarca().getText());
                    objA.setPlaca(frmA.getTxtPlaca().getText());
                    objA.setModelo(Integer.parseInt(frmA.getTxtModelo().getText()));
                    objA.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
                    objF.getListaV().add(objA);
                }
                case 1 -> {
                    Moto objM = new Moto();
                    objM.setMarca(frmA.getTxtMarca().getText());
                    objM.setPlaca(frmA.getTxtPlaca().getText());
                    objM.setModelo(Integer.parseInt(frmA.getTxtModelo().getText()));
                    objM.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
                    objF.getListaV().add(objM);

                    frmA.getPnlCil().setVisible(true);
                }
            }
            agregarVehiculo(frmA.getTblDatos(), objF);
        }

        if (e.getSource().equals(frmA.getBtnRegistrar())) {
            objF.getPropietario().setId(frmA.getTxtId().getText());
            objF.getPropietario().setNombre(frmA.getTxtNom().getText());
            objF.getPropietario().setTel(frmA.getTxtTel().getText());
            String fecha[] = frmA.getTxtFN().getText().split("/");
            objF.getPropietario().setfNac(new Fecha(Integer.parseInt(fecha[0]),
                    Integer.parseInt(fecha[1]),
                    Integer.parseInt(fecha[2])));
            //frmA.getTxtResp().append(objF.toString() + "\nTotal Pago= " + objF.valorPago());
        }
        if (e.getSource().equals(frmA.getBtnForm())) {
            objF.setRefCode("" + Math.round(Math.random() * 999));
            transferirDatosTabla(frmA.getTblDatos(), frmA.getTblForm());
        }

    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.JOptionPane;

/**
 *
 * @author Ingrid Rubio
 */
public class CajasMensaje {

    private String titulo;

    public CajasMensaje(String titulo) {
        this.titulo = titulo;
    }

    public CajasMensaje() {
        this.titulo = "";
    }

    public int leerEntero(String msg) {
        return Integer.parseInt(JOptionPane.showInputDialog(null, msg, this.titulo, JOptionPane.INFORMATION_MESSAGE));
    }

    public double leerDouble(String msg) {
        return Double.parseDouble(JOptionPane.showInputDialog(null, msg, this.titulo, JOptionPane.INFORMATION_MESSAGE));

    }

    public String leerTexto(String msg) {
        return JOptionPane.showInputDialog(null,
                msg,
                this.titulo,
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrar(String msg) {
        JOptionPane.showMessageDialog(null,
                msg,
                this.titulo,
                JOptionPane.INFORMATION_MESSAGE/*1*/);
    }

    @Override
    public String toString() {
        return "titulo= " + titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public boolean validar(String msg) {
        int resp = JOptionPane.showConfirmDialog(null, msg,
                this.titulo,
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (resp == JOptionPane.YES_NO_OPTION) {
            return true;
        } else {
            return false;
        }
    }
}

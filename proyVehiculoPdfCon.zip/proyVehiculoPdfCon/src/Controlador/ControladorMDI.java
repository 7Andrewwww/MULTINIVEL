/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 *
 * @author Estudiante
 */
public class ControladorMDI implements ActionListener {

    private MDIInicio frmI;
    private Recaudo objR;

    public ControladorMDI() {
        this.frmI = new MDIInicio();
        this.objR = new Recaudo();
        this.frmI.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.frmI.getMnuNuevoForm().addActionListener(this);
        this.frmI.getMnuSalir().addActionListener(this);
        this.frmI.getBtnNuevoForm().addActionListener(this);
        this.frmI.getBtnRecaudo().addActionListener(this);
        this.frmI.getMnuConsultarR().addActionListener(this);
        this.frmI.getBtnRecaudo().addActionListener(this);
        this.frmI.getBtnSalirr().addActionListener(this);

    }

    public void iniciar() {
        frmI.setTitle("Registro Autos");
        //frmI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmI.setLocationRelativeTo(null);
        frmI.setVisible(true);
    }

    public void agregarVehiculo(JTable tabla, Factura formV) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.registro());
    }

    public void transferirDatosTabla(JTable tabla1, JTable tabla2) {
        DefaultTableModel modeloOrigen = (DefaultTableModel) tabla1.getModel();
        DefaultTableModel modeloDestino = (DefaultTableModel) tabla2.getModel();
        // Limpiar la tabla de destino antes de transferir los datos para evitar duplicados
        modeloDestino.setRowCount(0);
        // Recorrer cada fila de la tabla origen y agregarla a la tabla destino
        for (int i = 0; i < modeloOrigen.getRowCount(); i++) {
            Object[] fila = new Object[modeloOrigen.getColumnCount()];
            for (int j = 0; j < modeloOrigen.getColumnCount(); j++) {
                fila[j] = modeloOrigen.getValueAt(i, j);
            }
            modeloDestino.addRow(fila);
        }
        modeloOrigen.setRowCount(0);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    public void agregarArchTabla(JTable tabla) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        Conexion con = new Conexion();
        try {
            String[] registros = con.leerDatos("vehiculos.txt").split("\n");
            for (String registro : registros) {
                String[] linea = registro.split(";");
                Object reg[] = {linea[0], linea[1], linea[2], linea[3], linea[4], linea[5]};
                plantilla.addRow(reg);
            }
        } catch (Exception err) {
            JOptionPane.showMessageDialog(frmI, "ERROR EN APERTURA DE ARCHIVO");
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmI.getMnuSalir()) || e.getSource().equals(frmI.getBtnSalirr())) {
            int resp = JOptionPane.showConfirmDialog(frmI, "Desea terminar la ejecucion?");
            if (resp == JOptionPane.YES_NO_OPTION) {
                frmI.dispose();//cierra limpia
            }
        }

        if (e.getSource().equals(frmI.getMnuConsultarR()) || e.getSource().equals(frmI.getBtnRecaudo())) {
            jIFRMConsulta frmC = new jIFRMConsulta();
            frmI.getJpdEscritorio().add(frmC);
            agregarArchTabla(frmC.getTblDatosV());
            frmC.setVisible(true);
             //Llamado al controlador JInternal
            ControladorJIConsultas ctrlFrmC = new ControladorJIConsultas();
            ctrlFrmC.iniciar();
           ;
        }

        if (e.getSource().equals(frmI.getMnuNuevoForm()) || e.getSource().equals(frmI.getBtnNuevoForm())) {
            jIFRMVehiculo frmA = new jIFRMVehiculo();
            frmI.getJpdEscritorio().add(frmA);
            //frmA.setVisible(true);
            //Llamado al controlador JInternal
            ControladorJIFrm ctrlFrmA = new ControladorJIFrm(frmA, objR);
            ctrlFrmA.iniciar();
        }

    }
}

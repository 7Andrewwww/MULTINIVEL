/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;

import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 *
 * @author Estudiante
 */
public class ControladorJIConsultas implements ActionListener {

    private jIFRMConsulta frmC;
    private Factura objF;
    private Recaudo objR;

    public ControladorJIConsultas() {
        this.frmC = new jIFRMConsulta();
        this.objF = new Factura();
        this.objR = new Recaudo();
        this.frmC.getBtnBuscar().addActionListener(this);//sensor boton
        
    }

    public ControladorJIConsultas(JInternalFrame form, Recaudo objR) {
        this.frmC = (jIFRMConsulta) form;
        this.objR=objR;
        this.objF = new Factura();
        this.frmC.getBtnBuscar().addActionListener(this);//sensor boton
        
    }

    public void iniciar() {
        frmC.setTitle("Registro Autos");
        frmC.setLocation(50, 10);
        frmC.setVisible(true);
    }

    public void agregarVehiculo(JTable tabla, Factura formV) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.registro());
    }

    public void transferirDatosTabla(JTable tabla1, JTable tabla2) {
        DefaultTableModel modeloOrigen = (DefaultTableModel) tabla1.getModel();
        DefaultTableModel modeloDestino = (DefaultTableModel) tabla2.getModel();
        // Limpiar la tabla de destino antes de transferir los datos para evitar duplicados
        modeloDestino.setRowCount(0);
        // Recorrer cada fila de la tabla origen y agregarla a la tabla destino
        for (int i = 0; i < modeloOrigen.getRowCount(); i++) {
            Object[] fila = new Object[modeloOrigen.getColumnCount()];
            for (int j = 0; j < modeloOrigen.getColumnCount(); j++) {
                fila[j] = modeloOrigen.getValueAt(i, j);
            }
            modeloDestino.addRow(fila);
        }
        modeloOrigen.setRowCount(0);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmC.getBtnBuscar())) {
            
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Auto;
import Modelo.Fecha;
import Modelo.Formulario;
import Vista.frmAuto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

/**
 *
 * @author Estudiante
 */
public class ControladorFrm implements ActionListener {
    private frmAuto frmA;
    private Formulario objF;

    public ControladorFrm() {
        this.frmA = new frmAuto();
        this.objF = new Formulario();
        this.frmA.getBtnRegistrar().addActionListener(this);//sensor boton
    }
    public void iniciar(){
        frmA.setTitle("Registro Autos");
        frmA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmA.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource().equals(frmA.getBtnRegistrar())){
           objF.getPropietario().setId(frmA.getTxtId().getText());
            objF.getPropietario().setNombre(frmA.getTxtNom().getText());
            objF.getPropietario().setTel(frmA.getTxtTel().getText());
            String fecha[] = frmA.getTxtFN().getText().split("/");
            objF.getPropietario().setfNac(new Fecha(Integer.parseInt(fecha[0]),
                                                    Integer.parseInt(fecha[1]),
                                                    Integer.parseInt(fecha[2])));
       
       Auto objA = new Auto();
                        objA.setMarca(frmA.getTxtMarca().getText());
                        objA.setPlaca(frmA.getTxtPlaca().getText());
                        objA.setModelo(Integer.parseInt(frmA.getTxtModelo().getText()));
                        objA.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
                        objF.getListaV().add(objA);
                        
                        frmA.getTxtResp().append(objF.toString() + "\nTotal Pago= " + objF.valorPago());
    }
    
    }
}

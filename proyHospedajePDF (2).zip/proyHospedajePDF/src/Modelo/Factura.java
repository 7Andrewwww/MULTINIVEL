/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author A n d r e s
 */
public class Factura {

   
    private String RefCode;
    private Fecha fechi;
    private ArrayList<Hospedaje> listaH;
    private Cliente cliente;

    public Factura(Fecha fechi, Hospedaje hospedaje, Cliente cliente, String RefCode) {
      
        this.fechi = fechi;
        this.listaH = listaH;
        this.cliente = cliente;
        this.RefCode = RefCode;
    }

    public Factura() {
        
        this.fechi = new Fecha();
        this.cliente = new Cliente();
        this.listaH = new ArrayList<Hospedaje>();
        this.RefCode = "";

    }

    public Factura(int tipoV) { //Cnstructor para inicializar el tipo de vehiculo
        this.RefCode = "F" + Math.round(Math.random() * 999);
        this.fechi = new Fecha();
        this.cliente = new Cliente();
        switch (tipoV) {
            case 1 ->
                this.listaH.add(new Camping());
            case 2 ->
                this.listaH.add(new Habitacion());
        }
    }

   

    public Fecha getFechi() {
        return fechi;
    }

    public void setFechi(Fecha fechi) {
        this.fechi = fechi;
    }

    public ArrayList<Hospedaje> getListaH() {
        return listaH;
    }

    public void setListaV(ArrayList<Hospedaje> listaV) {
        this.listaH = listaH;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public double valorPago() {
        double pagoImpuesto = 0;
        for (Hospedaje objH : listaH) {
            pagoImpuesto += objH.impuesto();
        }
        return pagoImpuesto;
    }

    public String getRefCode() {
        return RefCode;
    }

    public void setRefCode(String RefCode) {
        this.RefCode = RefCode;
    }
    
    

    public Object[] registro() {
        int posReg = this.getListaH().size() - 1;
        String tipo = "";
        if (this.getListaH().get(posReg) instanceof Camping) {
            tipo = "Camping";
        } else {
            tipo = "Habitación";
        }

        Object[] reg = {RefCode, this.fechi.toString(),
            this.getCliente().getId(),
            tipo,
            this.getListaH().get(posReg).getCanDia(),
            this.getListaH().get(posReg).getNumPer(),
            this.getListaH().get(posReg).impuesto()
        };
        return reg;
    }

    @Override
    public String toString() {
        return "Factura{"  +
                ", RefCode=" + RefCode + 
                ", fechi=" + fechi + 
                ", listaH=" + listaH + 
                ", cliente=" + cliente + '}';
    }

    
    

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author A n d r e s
 */
public class Camping extends Hospedaje {

    // Constructor
    public Camping(int canDia, int numPer, double precio) {
        super(canDia, numPer, precio);

    }

    public Camping() {
        super();
    }

    @Override
    public double valorPagar() {
        return canDia * descuento();
    }

    @Override
    public double descuento() {
        if (numPer > 2) {
            return precio = 40000;
        } else {
            return precio = 50000;
        }
    }

    @Override
    public double impuesto() {
        double IVA = 0.19;
        return valorPagar() * IVA;
    }

    @Override
    public String toString() {
        return "Camping{"
                + "canDia=" + canDia
                + ", numPer=" + numPer
                + ", precio=" + precio
                + +'}';
    }

}

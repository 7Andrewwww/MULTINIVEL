/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class Factura {

    private String RefCode;
    private Fecha fechi;
    private Persona propietario;
    private ArrayList<Vehiculo> listaV;

    public Factura(String RefCode, Fecha fechi, Persona propietario, ArrayList<Vehiculo> listaV) {
        this.RefCode = RefCode;
        this.fechi = fechi;
        this.propietario = propietario;
        this.listaV = listaV;
    }

    public Factura(int tipoV) { //Cnstructor para inicializar el tipo de vehiculo
        this.RefCode = "F" + Math.round(Math.random() * 999);
        this.fechi = new Fecha();
        this.propietario = new Persona();
        switch (tipoV) {
            case 1 ->
                //Auto se convierte en vehiculo POLIMORFISMO
                this.listaV.add(new Auto());
            case 2 ->
                //Moto se convierte en vehiculo POLIMORFISMO
                this.listaV.add(new Moto());
        }
    }
    
    public Factura() {
        this.RefCode = "" + Math.round(Math.random() * 999);
        this.fechi = new Fecha();
        this.propietario = new Persona();
        this.listaV = new ArrayList<Vehiculo>();
    }

    public String getRefCode() {
        return RefCode;
    }

    public void setRefCode(String RefCode) {
        this.RefCode = RefCode;
    }

    public Fecha getFechi() {
        return fechi;
    }

    public void setFechi(Fecha fechi) {
        this.fechi = fechi;
    }

    public Persona getPropietario() {
        return propietario;
    }

    public void setPropietario(Persona propietario) {
        this.propietario = propietario;
    }

    public ArrayList<Vehiculo> getListaV() {
        return listaV;
    }

    public void setListaV(ArrayList<Vehiculo> listaV) {
        this.listaV = listaV;
    }

    public double valorPago() {
        double pagoImpuesto = 0;
        for (Vehiculo objV : listaV) {
            pagoImpuesto += objV.impuesto();
        }
        return pagoImpuesto;
    }

    public String datos() {
        String lista = "";
        for (Vehiculo objV : listaV) {
            lista += objV.toString() + "\n Impuesto= " + String.format("%.0f", objV.impuesto());
        }
        return lista;
    }

    public Object[] registro() {
        int posReg = this.getListaV().size() - 1;
        String tipo = "";
        if (this.getListaV().get(posReg) instanceof Auto) {
            tipo = "Auto";
        } else 
            tipo = "Moto";
        
        Object[] reg = {RefCode, this.fechi.toString(),
            this.getPropietario().getId(),
            tipo,
            this.getListaV().get(posReg).getPlaca(),
            this.getListaV().get(posReg).impuesto()
        };
        return reg;
    }

    @Override
    public String toString() {
        return "Datos Factura: \n "
                + "Referencia: " + RefCode + "\n Fecha= " + fechi.toString() + "\n Propietario= " + propietario.toString() + "\n Lista Vehiculo= \n" + datos();
    }

}

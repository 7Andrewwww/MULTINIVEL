/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Persona {
    private String id, nombre, tel;
    private Fecha fNac;
    
    public Persona() {
        this.id = "";
        this.nombre = "";
        this.tel = "";
        this.fNac = new Fecha();
    }

    public Persona(String id, String nombre, String tel, Fecha fNac) {
        this.id = id;
        this.nombre = nombre;
        this.tel = tel;
        this.fNac = fNac;
    }
   
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public Fecha getfNac() {
        return fNac;
    }

    public void setfNac(Fecha fNac) {
        this.fNac = fNac;
    }
    
    public int edad(){
        return this.fNac.calcularAaa(this.fNac.getAa());
    }

    @Override
    public String toString() {
        return  "\n id=" + id + "\n Nombre=" + nombre + "\n Telefono=" + tel + "\t Nacimiento=" + fNac.toString();
    }
    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.*;
/**
 *
 * @author A n d r e s
 */
public class Conexion {
    protected BufferedReader bufEntrada;
    protected FileReader flujoLee;
    protected FileWriter flujoEsc;
    protected PrintWriter bufSalida;

    public Conexion(BufferedReader bufEntrada, FileReader flujoLee, FileWriter flujoEsc, PrintWriter bufSalida) {
        this.bufEntrada = bufEntrada;
        this.flujoLee = flujoLee;
        this.flujoEsc = flujoEsc;
        this.bufSalida = bufSalida;
    }
    
    public Conexion() throws IOException{
    this.bufEntrada = null;
    this.bufSalida = null;
    this.flujoEsc = null;
    this.flujoLee = null;
    }
    
    public String leerDatos() throws IOException{
    this.flujoLee = new FileReader("Agenga.txt");
    bufEntrada = new BufferedReader(flujoLee);
    String datos = "";
    String linea = this.bufEntrada.readLine();
        while (linea!= null) {            
         datos += linea+"\n";  
         linea = bufEntrada.readLine();
        }
        bufEntrada.close();
        return datos;
    }

   public void escribeDatos(String datos) throws IOException{
   flujoEsc = new FileWriter("Agenda.txt",true);
   bufSalida = new PrintWriter(flujoEsc);
   bufSalida.print(datos);
   bufSalida.close();
   } 
}

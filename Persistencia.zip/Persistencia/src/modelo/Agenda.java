/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author A n d r e s
 */
public class Agenda {
    ArrayList <Persona> contactos;

    public Agenda(ArrayList<Persona> contactos) {
        this.contactos = contactos;
    }
    public Agenda() {
        this.contactos = new <Persona> ArrayList();
    }

    public ArrayList<Persona> getContactos() {
        return contactos;
    }

    public void setContactos(ArrayList<Persona> contactos) {
        this.contactos = contactos;
    }

    @Override
    public String toString() {
        String datos = "";
        for (int i = 0; i < contactos.size(); i++) {
            datos+=contactos.get(i).toString()+ "\n";
        }
        return datos;
    }
    
}

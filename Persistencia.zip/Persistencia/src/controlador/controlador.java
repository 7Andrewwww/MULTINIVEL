/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.Component;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.*;
import modelo.*;
import vista.*;

/**
 *
 * @author A n d r e s
 */
public class controlador implements ActionListener {

    Agenda agenda;
    frmPer frmV;
    Conexion con;

    public controlador(Agenda agenda, frmPer frmV, Conexion con) throws IOException {
        this.agenda = agenda;
        this.frmV = frmV;
        this.con = new Conexion();
        frmV.getBtnAgregar().addActionListener(this);
        frmV.getBtnArch().addActionListener(this);
    }

    public controlador() throws IOException {
        this.agenda = new Agenda();
        this.frmV = new frmPer();
        this.con = new Conexion();
        frmV.getBtnAgregar().addActionListener(this);
        frmV.getBtnArch().addActionListener(this);
    }

    public void iniciar() {
        frmV.setTitle("Agenda");
        frmV.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmV.getBtnAgregar())) {
            try {
                Persona contacto = new Persona();
                frmV.getTxtNombre().getText();
                frmV.getTxtTelefono().getText();
                frmV.getTxtEmail().getText();
                agenda.getContactos().add(contacto);
                con.escribeDatos(contacto.datos());
                JOptionPane.showMessageDialog(frmV,
                        "Datos Registrados...\n"
                        + contacto.toString());
                iniciarControles(frmV.getJpnlConsultar().getComponents());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frmV, "Error al acceder al archivo...");
            }
        }
        if (e.getSource().equals(frmV.getBtnArch())) {
            try {
                iniciarTabla(frmV.getTblArchContactos());
                String agenda[] = con.leerDatos().split("\n");
                for (String registro : agenda) {
                    String datos[] = registro.split(";");
                    Persona contacto = new Persona(datos[0], datos[1], datos[2]);
                    agregarContactoTabla(contacto, frmV, getTblArchContactos());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frmV, "Error al acceder al archivo...");
            }

        }

    }

    public void agregarContactos(Persona cont, JTable tabla) {
        Object datos[] = {cont.getNom(), cont.getTel(), cont.getEmail()};
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(datos);
    }

    public void llenarLista(String contactos, JTable tabla) {
        String Agenda[] = contactos.split("\n");
        for (int i = 0; i < Agenda.length; i++) {
            String datos[] = Agenda[i].split(";");
            System.out.println("Registro" + Agenda[i].toString());
            Persona contacto = new Persona(
                    datos[0],
                    datos[1],
                    datos[2]);
            agregarContactos(contacto, tabla);
        }
    }

    public void iniciarControles(Component[] Controles) {
        for (Object Control : Controles) {
            if (Control instanceof JPanel) {
                iniciarControles(((JPanel) Control).getComponents());
            } else if (Control instanceof JTextField) {
                ((JTextField)Control).setText("");
            }
        }

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.*;

import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 *
 * @author Estudiante
 */
public class ControladorJIFrm implements ActionListener {

    private jIFRMHospedaje frmH;
    private Factura objF;
    

    public ControladorJIFrm() {
        this.frmH = new jIFRMHospedaje();
        this.objF = new Factura();
        this.frmH.getBtnRegistrar2().addActionListener(this);//sensor boton
        this.frmH.getCmbTipoH().addActionListener(this);
        this.frmH.getBtnAgregarH().addActionListener(this);
        this.frmH.getBtnForm().addActionListener(this);
    }

    public ControladorJIFrm(JInternalFrame form) {
        this.frmH = (jIFRMHospedaje) form;
        this.objF = new Factura();
        this.frmH.getBtnRegistrar2().addActionListener(this);//sensor boton
        this.frmH.getCmbTipoH().addActionListener(this);
        this.frmH.getBtnAgregarH().addActionListener(this);
        this.frmH.getBtnForm().addActionListener(this);
    }

    public void iniciar() {
        frmH.setTitle("Registro Hospedaje");
        frmH.setLocation(50, 10);
        frmH.setVisible(true);
    }

    public void agregarHospedaje(JTable tabla, Factura formV) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.registro());
    }

    public void transferirDatosTabla(JTable tabla1, JTable tabla2) {
        DefaultTableModel modeloOrigen = (DefaultTableModel) tabla1.getModel();
        DefaultTableModel modeloDestino = (DefaultTableModel) tabla2.getModel();
        // Limpiar la tabla de destino antes de transferir los datos para evitar duplicados
        modeloDestino.setRowCount(0);
        // Recorrer cada fila de la tabla origen y agregarla a la tabla destino
        for (int i = 0; i < modeloOrigen.getRowCount(); i++) {
            Object[] fila = new Object[modeloOrigen.getColumnCount()];
            for (int j = 0; j < modeloOrigen.getColumnCount(); j++) {
                fila[j] = modeloOrigen.getValueAt(i, j);
            }
            modeloDestino.addRow(fila);
        }
        modeloOrigen.setRowCount(0);
    }

    public void iniciarControles(Component[] controles) {
        //Component[] controles = ventana.getContentPane().getComponents();
        int canTab = 0;
        for (Component control : controles) {
            if (control instanceof JTabbedPane) {
                canTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < canTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }

            } else if (control instanceof JPanel) {
                for (Component controlP : ((JPanel) control).getComponents()) {
                    if (controlP instanceof JTextField) {
                        ((JTextField) controlP).setText("");
                    } else if (controlP instanceof JPanel) {
                        iniciarControles(((JPanel) controlP).getComponents());
                    }
                }
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    
        if (e.getSource().equals(frmH.getBtnAgregarH())) {
            try {
                switch (frmH.getCmbTipoH().getSelectedIndex()) {
                    case 0 -> {
                        Camping objC = new Camping();
                        objC.setCanDia(Integer.parseInt(frmH.getTxtCanNoc().getText()));
                        objC.setNumPer(Integer.parseInt(frmH.getTxtCanNoc().getText()));
                        objF.getListaH().add(objC);
                    }
                    case 1 -> {
                        Habitacion objH = new Habitacion();
                        objH.setCanDia(Integer.parseInt(frmH.getTxtCanNoc().getText()));
                        objH.setNumPer(Integer.parseInt(frmH.getTxtCanNoc().getText()));
                        objF.getListaH().add(objH);
                    }
                }
                agregarHospedaje(frmH.getTblDatos(), objF);
            } catch (NumberFormatException ex) {
                //JOptionPane.showMessageDialog(frmA, "ERROR" + ex.getMessage());
                String[] valErr = ex.toString().split(":");
                JOptionPane.showMessageDialog(frmH, "ERROR AL INGRESAR EL DATO " + valErr[2]
                        + "Se requiere un dato NUMERICO");
            }
        }

        if (e.getSource().equals(frmH.getBtnRegistrar2())) {
            objF.getCliente().setId(frmH.getTxtId().getText());
            objF.getCliente().setNombre(frmH.getTxtNom().getText());
            objF.getCliente().setTel(frmH.getTxtTel().getText());
            String fecha[] = frmH.getTxtFN().getText().split("/");
            objF.getCliente().setfNac(new Fecha(Integer.parseInt(fecha[0]),
                    Integer.parseInt(fecha[1]),
                    Integer.parseInt(fecha[2])));
            //frmA.getTxtResp().append(objF.toString() + "\nTotal Pago= " + objF.valorPago());
        }
        if (e.getSource().equals(frmH.getBtnForm())) {
            ArchPdf arch = new ArchPdf();
            arch.crear_PDF(objF);
            iniciarControles(frmH.getContentPane().getComponents());
            objF.setRefCode("" + Math.round(Math.random() * 999));
            transferirDatosTabla(frmH.getTblDatos(), frmH.getTblForm());
        }

    }
}

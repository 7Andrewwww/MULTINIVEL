/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.ControladorCM;
import Controlador.ControladorFrm;


/**
 *
 * @author Estudiante
 */
public class Main {
    public static void main (String[] args){
        ControladorFrm ct= new ControladorFrm();
        ct.iniciar();
    }
}

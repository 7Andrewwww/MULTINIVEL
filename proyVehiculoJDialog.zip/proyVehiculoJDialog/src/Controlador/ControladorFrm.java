/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import Vista.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Estudiante
 */
public class ControladorFrm implements ActionListener {

    private frmVehiculo frmA;
    private ventanaDialog vDialog;
    private Formulario objF;

    public ControladorFrm() {
        this.frmA = new frmVehiculo();
        this.objF = new Formulario();
        this.vDialog = new ventanaDialog(frmA, true);
        this.vDialog.getBtnCerrar().addActionListener(this);
        // Primer Parametro (Establecer la ventana padre)
        // Segundo Parametro (Decidir si es una ventana modal o no)
        // Principal Funcion: Actuar como ventana modal
        this.frmA.getBtnRegistrar().addActionListener(this);
        this.frmA.getCmbTipoV().addActionListener(this);
        this.frmA.getBtnAgregarV().addActionListener(this);
    }

    public void iniciar() {
        frmA.setTitle("Registro Autos");
        frmA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmA.setLocationRelativeTo(null);
        frmA.getPnlCil().setVisible(false);
        frmA.getBtnRegistrar().setVisible(false);
        vDialog.setTitle("Error Datos");
        vDialog.setLocationRelativeTo(null);
        frmA.setVisible(true);
    }

    public void agregarVehiculo(JTable tabla, Formulario formV) {
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(formV.registro());
    }

    public void iniciarControles(Component[] controles) {
        // Component[] controles = ventana.getContentPane().getComponents();

        int cantTab = 0;
        for (Component control : controles) {
            cantTab++;
            if (control instanceof JTabbedPane) {
                cantTab = ((JTabbedPane) control).getTabCount();
                for (int i = 0; i < cantTab; i++) {
                    Component panel = ((JTabbedPane) control).getComponent(i);
                    if (panel instanceof JPanel) {
                        iniciarControles(((JPanel) panel).getComponents());
                    }
                }
            } else if (control instanceof JPanel) {
                iniciarControles(((JPanel) control).getComponents());
            } else if (control instanceof JTextField) {
                ((JTextField) control).setText("");
            } else if (control instanceof JTable) {
                iniciarTabla((JTable) control);
            }
        }
    }

    public void iniciarTabla(JTable tabla) {
        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
        int controw = modeloTabla.getRowCount();
        for (int i = controw - 1; i >= 0; i--) {
            modeloTabla.removeRow(i);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmA.getCmbTipoV())) {
            switch (frmA.getCmbTipoV().getSelectedIndex()) {
                case 0 -> {
                    frmA.getPnlCil().setVisible(false);
                }
                case 1 -> {
                    frmA.getPnlCil().setVisible(true);
                }
            }
        }

        if (e.getSource().equals(frmA.getBtnAgregarV())) {
            try {
                frmA.getBtnRegistrar().setVisible(true);
                objF.getPropietario().setId(frmA.getTxtId().getText());
                objF.getPropietario().setNombre(frmA.getTxtNom().getText());
                objF.getPropietario().setTel(frmA.getTxtTel().getText());
                String fecha[] = frmA.getTxtFN().getText().split("/");
                objF.getPropietario().setfNac(new Fecha(Integer.parseInt(fecha[0]),
                        Integer.parseInt(fecha[1]),
                        Integer.parseInt(fecha[2])));
                switch (frmA.getCmbTipoV().getSelectedIndex()) {
                    case 0 -> {
                        Auto objA = new Auto();
                        objA.setMarca(frmA.getTxtMarca().getText());
                        objA.setPlaca(frmA.getTxtPlaca().getText());
                        objA.setModelo(Integer.parseInt(frmA.getTxtModelo().getText()));
                        objA.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
                        objF.getListaV().add(objA);
                    }
                    case 1 -> {
                        Moto objM = new Moto();
                        objM.setMarca(frmA.getTxtMarca().getText());
                        objM.setPlaca(frmA.getTxtPlaca().getText());
                        objM.setModelo(Integer.parseInt(frmA.getTxtModelo().getText()));
                        objM.setValor(Double.parseDouble(frmA.getTxtValor().getText()));
                        objM.setCilindraje(Integer.parseInt(frmA.getTxtCil().getText()));
                        objF.getListaV().add(objM);

                        frmA.getPnlCil().setVisible(true);
                    }
                }
                agregarVehiculo(frmA.getTblDatos(), objF);
            } catch (NumberFormatException ex) {
                String valExcep[] = ex.toString().split(":");
                vDialog.getLblError().setText(valExcep[2]);
                vDialog.setVisible(true);
                /*JOptionPane.showMessageDialog(frmA, "Error al ingresar el dato : " + valExcep[2]
                        + "\nSe requiere un dato numerico");*/
            }

        }
        
        if(e.getSource().equals(vDialog.getBtnCerrar())){
            vDialog.dispose();
        }

        //Botón Registrar
        if (e.getSource().equals(frmA.getBtnRegistrar())) {
            frmA.getBtnRegistrar().setVisible(false);
            iniciarControles(frmA.getContentPane().getComponents());
        }
    }
}
